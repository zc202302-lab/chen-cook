"""Dedicated desktop window. The browser is never launched."""
import json
import os
import socket
import traceback
import threading
import time
from pathlib import Path


def bind_desktop_socket(port):
    """Reserve the listener before starting the server; keep it reserved."""
    listener=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    try:
        if os.name=='nt':listener.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        try:listener.bind(('127.0.0.1',port))
        except OSError as exc:
            if exc.errno not in (48,98,10048) and getattr(exc,'winerror',None)!=10048:raise
            listener.bind(('127.0.0.1',0))
        listener.listen(128)
        listener.setblocking(False)
        return listener
    except BaseException:
        listener.close()
        raise


def run_desktop(application, server, root, port, view=None):
    if view is None:
        import webview as view
    root=Path(root)
    closing=threading.Event()
    server_done=threading.Event()
    application.state.desktop_ready=False

    listener=bind_desktop_socket(port)
    port=listener.getsockname()[1]
    updates=root/'.updates';updates.mkdir(exist_ok=True)
    endpoint=updates/'desktop-endpoint.json'
    endpoint.write_text(json.dumps({'port':port,'pid':os.getpid()}),encoding='utf-8')
    failures=[]
    def serve():
        try:server.run(sockets=[listener])
        except BaseException as exc:
            failures.append(exc)
            traceback.print_exc()
        finally:
            listener.close()
            server_done.set()
    backend=threading.Thread(target=serve,daemon=True);backend.start()
    deadline=time.monotonic()+30
    while not server.started:
        if server_done.is_set() or time.monotonic()>deadline:
            server.should_exit=True
            detail=str(failures[0]) if failures else '后台提前退出或启动超时'
            raise RuntimeError('桌面后台启动失败：'+detail)
        time.sleep(.05)
    view.settings['ALLOW_DOWNLOADS']=True
    view.settings['OPEN_EXTERNAL_LINKS_IN_BROWSER']=False
    window=view.create_window('灶间书房 · 转换工作台',f'http://127.0.0.1:{port}',
                              width=1280,height=860,min_size=(950,650),
                              background_color='#f8f6f0',text_select=True)

    def shutdown():
        closing.set()
        server.should_exit=True
        window.destroy()
    application.state.shutdown_for_update=shutdown

    def on_closing():
        if closing.is_set():return True
        if getattr(application.state,'update_in_progress',False):return False
        # Request graceful shutdown rather than hiding a conversion service in the background.
        def save_and_close():
            try:window.evaluate_js('void desktopSaveAndQuit()')
            except Exception:application.state.request_quit()
        threading.Thread(target=save_and_close,daemon=True).start()
        return False

    def on_loaded():
        application.state.desktop_ready=True
        try:
            from webview.dom import DOMEventHandler
            def dropped(event):
                paths=[f['pywebviewFullPath'] for f in event.get('dataTransfer',{}).get('files',[])
                       if f.get('pywebviewFullPath','').lower().endswith('.pdf')]
                if paths:window.evaluate_js('acceptDesktopPaths('+json.dumps(paths,ensure_ascii=False)+')')
            area=window.dom.get_element('#desktopDrop')
            if area:area.events.drop+=DOMEventHandler(dropped,prevent_default=True)
        except Exception as exc:
            print('拖入文件功能暂不可用，可通过选择文件添加：',exc)

    def monitor():
        server_done.wait()
        if not closing.is_set():
            closing.set();window.destroy()

    window.events.closing+=on_closing
    window.events.loaded+=on_loaded
    try:
        view.start(monitor,gui='edgechromium' if os.name=='nt' else None,
                   private_mode=False,storage_path=str(root/'.desktop'))
    finally:
        if not server_done.is_set():
            # GUI initialization failed or was terminated: save page checkpoints before exiting.
            if not closing.is_set():application.state.request_quit()
            backend.join()


def show_error(exc):
    if os.name=='nt':
        import ctypes
        ctypes.windll.user32.MessageBoxW(None,
            '桌面窗口启动失败：'+str(exc)[:400]+'\n\n详细日志：.updates/application.log',
            '灶间书房',0x10)
