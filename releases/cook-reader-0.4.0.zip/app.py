import argparse
import copy
import hmac
import io
import json
import os
import queue
import re
import tempfile
import threading
import time
import uuid
import zipfile
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from storage import (ASSET, ID, LOCK, atomic_json, export_book, import_book,
                     public_book, read_json, validate_book, trash_book, list_trash, restore_book, purge_book)
import updater


def create_app(data=None, mode=None):
    root=Path(data or os.environ.get('COOK_DATA','data')).resolve()
    books=root/'books';books.mkdir(parents=True,exist_ok=True)
    jobs_path=root/'jobs.json'
    mode=mode or os.environ.get('COOK_MODE','local')
    local=mode=='local'
    appdir=Path(__file__).resolve().parent
    updating=threading.Event()
    update_lock=threading.Lock()
    app=FastAPI(title='灶间书房',docs_url=None,redoc_url=None)
    app.state.root=root
    jobs=read_json(jobs_path) if jobs_path.exists() else {}
    tasks=queue.Queue()
    for job in jobs.values():
        if local and job.pop('resume_after_update',False):
            job['status']='queued';tasks.put(job['id'])
        elif job['status'] in ('running','queued','pausing'):
            job['status']='paused'
            job['error']='程序曾中断，点击继续即可从已完成页面接着处理'

    def persist():
        atomic_json(jobs_path,jobs)

    def directory(bid):
        if not ID.fullmatch(bid):
            raise HTTPException(404,'书籍不存在')
        d=books/bid
        if not (d/'book.json').is_file():
            raise HTTPException(404,'书籍不存在')
        return d

    def local_only():
        if not local:
            raise HTTPException(403,'此功能只在电脑工作台使用')

    def sync_key(request):
        if local:return
        token=os.environ.get('COOK_SYNC_TOKEN','')
        if not token or not hmac.compare_digest(request.headers.get('x-sync-token',''),token):
            raise HTTPException(403,'同步密钥未配置或不正确')

    @app.middleware('http')
    async def protection(request,call_next):
        # Loopback UI accepts only same-origin mutations; prevents hostile websites driving file APIs.
        if local:
            host=request.headers.get('host','').split(':')[0]
            if host not in ('127.0.0.1','localhost','testserver'):
                return JSONResponse({'detail':'本地工作台只接受本机访问'},403)
        if request.method not in ('GET','HEAD','OPTIONS'):
            origin=request.headers.get('origin')
            if origin and urlsplit(origin).netloc.lower()!=request.headers.get('host','').lower():
                return JSONResponse({'detail':'不接受跨站写入请求'},403)
            if updating.is_set():
                return JSONResponse({'detail':'正在准备更新，请等待自动重启后再操作'},503)
        result=await call_next(request)
        result.headers['X-Content-Type-Options']='nosniff'
        result.headers['Referrer-Policy']='same-origin'
        scripts="'self' 'unsafe-inline' 'unsafe-eval'" if local and os.environ.get('COOK_DESKTOP')=='1' else "'self'"
        result.headers['Content-Security-Policy']="default-src 'self'; script-src "+scripts+"; style-src 'self' 'unsafe-inline'; img-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'"
        return result

    def worker():
        converter=None
        while True:
            if updating.is_set():
                time.sleep(.2);continue
            jid=tasks.get()
            with LOCK:
                if updating.is_set():
                    tasks.put(jid);tasks.task_done();continue
                job=jobs.get(jid)
                if not job or job['status']!='queued':
                    tasks.task_done();continue
                job.update(status='running',error='');persist()
            try:
                import fitz
                from engine import Converter
                if converter is None:converter=Converter()
                d=books/job['book_id']
                with fitz.open(job['source']) as pdf:
                    for index in job['indices']:
                        if job['status']=='pausing':
                            job['status']='paused'
                            break
                        with LOCK:
                            book=read_json(d/'book.json')
                            done={p['page'] for p in book['pages']}
                        if index+1 in done:continue
                        page=converter.page(pdf,index,d/'assets')
                        with LOCK:
                            book=read_json(d/'book.json')
                            book['pages'].append(page);book['pages'].sort(key=lambda p:p['page'])
                            book['revision']+=1
                            atomic_json(d/'book.json',book)
                            job['done']=len(book['pages']);persist()
                with LOCK:
                    if job['status']=='pausing':job['status']='paused'
                    elif job['status']!='paused':job['status']='done'
                    book=read_json(d/'book.json');book['status']=job['status']
                    from engine import organize_book
                    organize_book(book);book['revision']+=1
                    atomic_json(d/'book.json',book);persist()
            except Exception as exc:
                with LOCK:
                    jobs[jid].update(status='failed',error=str(exc));persist()
            finally:tasks.task_done()

    if local:
        threading.Thread(target=worker,daemon=True).start()

    @app.get('/api/config')
    def config():
        result={'mode':mode,'version':updater.current(appdir),'supervised':os.environ.get('COOK_SUPERVISED')=='1',
                'desktop':local and os.environ.get('COOK_DESKTOP')=='1',
                'desktop_ready':getattr(app.state,'desktop_ready',False)}
        if local:result['process_id']=os.getpid()
        return result

    def update_config():
        p=appdir/'.updates'/'config.json'
        config=read_json(p) if p.exists() else {}
        return {'feed':config.get('feed') or 'https://raw.githubusercontent.com/zc202302-lab/chen-cook/main/releases/latest.json'}

    @app.get('/api/update')
    def update_status():
        local_only();p=appdir/'.updates'/'status.json'
        return {**update_config(),'current':updater.current(appdir),
                'supervised':os.environ.get('COOK_SUPERVISED')=='1',
                'status':read_json(p) if p.exists() else {'phase':'idle'}}

    @app.put('/api/update')
    def configure_update(body:dict):
        local_only()
        try:feed=updater.https_url(body.get('feed','').strip())
        except ValueError as exc:raise HTTPException(400,str(exc))
        atomic_json(appdir/'.updates'/'config.json',{'feed':feed})
        return {'ok':True}

    @app.post('/api/update/check')
    def check_update():
        local_only();feed=update_config()['feed']
        if not feed:raise HTTPException(400,'尚未设置更新源，请先填写固定的版本信息地址')
        try:return updater.check(feed,appdir)
        except Exception as exc:raise HTTPException(400,'检查更新失败：'+str(exc))

    @app.post('/api/update/install')
    def install_update():
        local_only()
        if os.environ.get('COOK_SUPERVISED')!='1' or not hasattr(app.state,'shutdown_for_update'):
            raise HTTPException(409,'请关闭当前程序，双击灶间书房.exe 启动后再检查更新')
        feed=update_config()['feed']
        if not feed:raise HTTPException(400,'尚未设置更新源')
        if not update_lock.acquire(blocking=False):raise HTTPException(409,'已有更新任务正在运行')
        def run_update():
            app.state.update_in_progress=True
            try:
                updater.state(appdir,phase='checking',message='正在检查版本')
                info=updater.check(feed,appdir)
                if not info['available']:
                    updater.state(appdir,phase='done',message='已是最新版本');return
                updater.state(appdir,phase='downloading',message='正在下载并校验更新包',version=info['version'])
                staged=updater.stage(appdir,info)
                updating.set()
                updater.state(appdir,phase='waiting',message='等待当前页保存后自动更新，请勿关闭程序')
                with LOCK:
                    for j in jobs.values():
                        if j['status'] in ('queued','running','pausing'):
                            j['resume_after_update']=True
                            if j['status']=='running':j['status']='pausing'
                    persist()
                while any(j['status'] in ('running','pausing') for j in jobs.values()):time.sleep(.2)
                atomic_json(appdir/'.updates'/'pending.json',{'staged':str(staged)})
                updater.state(appdir,phase='restarting',message='已保存进度，正在安装并自动重启')
                app.state.shutdown_for_update()
            except Exception as exc:
                updating.clear()
                updater.state(appdir,phase='failed',message='更新失败：'+str(exc))
            finally:
                app.state.update_in_progress=False
                update_lock.release()
        threading.Thread(target=run_update,daemon=True).start()
        return {'ok':True}

    @app.get('/api/releases/latest')
    def latest_release():
        p=root/'releases'/'latest.json'
        if not p.is_file():raise HTTPException(404,'尚未发布版本信息')
        return FileResponse(p,headers={'Cache-Control':'no-store'})

    @app.get('/api/releases/{name}')
    def release_archive(name:str):
        if not re.fullmatch(r'cook-reader-\d+\.\d+\.\d+\.zip',name):raise HTTPException(404)
        p=root/'releases'/name
        if not p.is_file():raise HTTPException(404)
        return FileResponse(p)

    @app.get('/api/books')
    def listing():
        items=[]
        for p in books.glob('*/book.json'):
            b=read_json(p)
            blocks=[x for pg in b['pages'] for x in pg['blocks']]
            cover=next((x['src'] for x in blocks if x['kind']=='image'),None)
            items.append(dict(id=b['id'],title=b['title'],pages=len(b['pages']),
                              page_count=b.get('page_count',0),cover=cover,
                              pending=sum(not x.get('reviewed') for x in blocks),status=b.get('status','done')))
        return items

    @app.delete('/api/books/{bid}')
    def delete_converted_book(bid:str,request:Request):
        local_only()
        directory(bid)
        with LOCK:
            if any(j['book_id']==bid and j['status'] in ('running','pausing') for j in jobs.values()):
                raise HTTPException(409,'本书仍在转换，请先暂停并等待当前页保存后再删除')
            try:result=trash_book(root,bid)
            except ValueError as exc:raise HTTPException(409,str(exc))
            related={k:v for k,v in jobs.items() if v['book_id']==bid}
            try:
                if related:atomic_json(root/'trash'/result['trash_id']/'.jobs.json',related)
                for key in related:jobs.pop(key)
                persist()
            except BaseException:
                jobs.update(related)
                restore_book(root,result['trash_id'])
                (books/bid/'.jobs.json').unlink(missing_ok=True)
                raise
        return result

    @app.get('/api/trash')
    def deleted_books(request:Request):
        local_only()
        with LOCK:return list_trash(root)

    @app.post('/api/trash/{tid}/restore')
    def restore_converted_book(tid:str,request:Request):
        local_only()
        with LOCK:
            try:result=restore_book(root,tid)
            except ValueError as exc:raise HTTPException(409,str(exc))
            saved=directory(result['id'])/'.jobs.json'
            if saved.exists():
                for key,value in read_json(saved).items():
                    value.pop('resume_after_update',None)
                    if value['status'] in ('running','queued','pausing'):value['status']='paused'
                    jobs.setdefault(key,value)
                persist();saved.unlink()
        return result

    @app.delete('/api/trash/{tid}')
    def purge_converted_book(tid:str,request:Request):
        local_only()
        try:purge_book(root,tid)
        except ValueError as exc:raise HTTPException(404,str(exc))
        return {'ok':True}

    @app.get('/api/books/{bid}')
    def get_book(bid:str):return public_book(read_json(directory(bid)/'book.json'))

    @app.post('/api/books/{bid}/organize')
    def organize(bid:str,body:dict):
        local_only();d=directory(bid)
        from engine import organize_book
        with LOCK:
            if any(j['book_id']==bid and j['status'] in ('running','queued','pausing') for j in jobs.values()):
                raise HTTPException(409,'请先暂停或等待本书转换完成')
            book=read_json(d/'book.json')
            if body.get('revision')!=book['revision']:raise HTTPException(409,'内容已变化，请重新打开')
            before=copy.deepcopy(book)
            # Older books have OCR boxes but no rendered-page size. Recover size locally without OCR.
            source=next((j['source'] for j in jobs.values() if j['book_id']==bid),None)
            if source and Path(source).is_file():
                import fitz, math
                with fitz.open(source) as pdf:
                    for pg in book['pages']:
                        if not pg.get('ocr_size') and 1<=pg['page']<=len(pdf):
                            rect=pdf[pg['page']-1].rect;scale=min(2.5,1800/max(rect.width,rect.height))
                            pg['ocr_size']=[math.ceil(rect.width*scale),math.ceil(rect.height*scale)]
            summary=organize_book(book)
            atomic_json(d/'structure-backups'/f"revision-{before['revision']}.json",before)
            book['revision']+=1;atomic_json(d/'book.json',book)
        return {'book':public_book(book),'summary':summary}

    @app.put('/api/books/{bid}')
    def save_book(bid:str,body:dict):
        local_only();d=directory(bid)
        with LOCK:
            book=read_json(d/'book.json')
            if body.get('revision')!=book['revision']:
                raise HTTPException(409,'内容已变化，请重新打开后再修改')
            proposed=copy.deepcopy(book)
            proposed['title']=body.get('title',book['title'])
            proposed['pages']=copy.deepcopy(body.get('pages',book['pages']))
            original_pages={p['page']:p for p in book['pages']}
            for page in proposed['pages']:
                for key in ('ocr_lines','ocr_size'):
                    if key in original_pages.get(page['page'],{}):page[key]=original_pages[page['page']][key]
                for block in page['blocks']:
                    if block.get('catalog',{}).get('text_snapshot')!=block.get('text'):block.pop('catalog',None)
            try:validate_book(proposed)
            except ValueError as exc:raise HTTPException(400,str(exc))
            for pg in proposed['pages']:
                for block in pg['blocks']:
                    if block['kind']=='image' and not(d/'assets'/block['src']).is_file():
                        raise HTTPException(400,'图片不存在')
            proposed['revision']+=1;atomic_json(d/'book.json',proposed)
        return public_book(proposed)

    @app.get('/api/books/{bid}/assets/{name}')
    def asset(bid:str,name:str):
        d=directory(bid)
        if not ASSET.fullmatch(name) or not(d/'assets'/name).is_file():raise HTTPException(404)
        return FileResponse(d/'assets'/name)

    @app.get('/api/jobs')
    def get_jobs():
        local_only()
        with LOCK:
            return [{k:v for k,v in j.items() if k not in ('source','indices')} for j in jobs.values()]

    @app.post('/api/pick')
    def pick():
        local_only()
        if os.name=='nt':
            import ctypes
            from ctypes import wintypes as W
            class OPENFILENAME(ctypes.Structure):
                _fields_=[('lStructSize',W.DWORD),('hwndOwner',W.HWND),('hInstance',W.HINSTANCE),
                          ('lpstrFilter',W.LPCWSTR),('lpstrCustomFilter',W.LPWSTR),('nMaxCustFilter',W.DWORD),
                          ('nFilterIndex',W.DWORD),('lpstrFile',W.LPWSTR),('nMaxFile',W.DWORD),
                          ('lpstrFileTitle',W.LPWSTR),('nMaxFileTitle',W.DWORD),('lpstrInitialDir',W.LPCWSTR),
                          ('lpstrTitle',W.LPCWSTR),('Flags',W.DWORD),('nFileOffset',W.WORD),('nFileExtension',W.WORD),
                          ('lpstrDefExt',W.LPCWSTR),('lCustData',ctypes.c_ssize_t),('lpfnHook',ctypes.c_void_p),
                          ('lpTemplateName',W.LPCWSTR),('pvReserved',ctypes.c_void_p),('dwReserved',W.DWORD),('FlagsEx',W.DWORD)]
            buffer=ctypes.create_unicode_buffer(65536)
            dialog=OPENFILENAME();dialog.lStructSize=ctypes.sizeof(dialog)
            dialog.lpstrFilter='PDF 文件\0*.pdf\0\0';dialog.nFilterIndex=1
            dialog.lpstrFile=ctypes.cast(buffer,W.LPWSTR);dialog.nMaxFile=len(buffer)
            dialog.lpstrTitle='选择要转换的 PDF（可多选）'
            dialog.Flags=0x80000|0x200|0x1000|0x800|0x8
            if not ctypes.windll.comdlg32.GetOpenFileNameW(ctypes.byref(dialog)):
                error=ctypes.windll.comdlg32.CommDlgExtendedError()
                if error:raise HTTPException(400,f'选择文件失败（{error}），可以改为粘贴路径')
                return {'paths':[]}
            parts=buffer[:].split('\0');parts=parts[:parts.index('')]
            return {'paths':parts if len(parts)==1 else [str(Path(parts[0])/p) for p in parts[1:]]}
        import tkinter as tk
        from tkinter import filedialog
        window=tk.Tk();window.withdraw();window.attributes('-topmost',True)
        try:paths=filedialog.askopenfilenames(title='选择要转换的 PDF（可多选）',filetypes=[('PDF','*.pdf')])
        finally:window.destroy()
        return {'paths':list(paths)}

    quit_requested=threading.Event()
    def request_quit():
        if quit_requested.is_set():return
        quit_requested.set()
        def finish():
            updating.set()
            with LOCK:
                for j in jobs.values():
                    if j['status']=='running':j['status']='pausing'
                persist()
            while any(j['status'] in ('running','pausing') for j in jobs.values()):time.sleep(.2)
            app.state.shutdown_for_update()
        threading.Thread(target=finish,daemon=True).start()
    app.state.request_quit=request_quit

    @app.post('/api/quit')
    def quit_local():
        local_only()
        if not hasattr(app.state,'shutdown_for_update'):raise HTTPException(409,'此运行方式不支持退出')
        request_quit()
        return {'ok':True}

    @app.post('/api/jobs')
    def create_job(body:dict):
        local_only()
        from engine import fingerprint
        import fitz
        created=[]
        paths=body.get('paths',[])
        if not isinstance(paths,list) or not paths or len(paths)>500:raise HTTPException(400,'请选择 1～500 个 PDF')
        for raw in paths:
            path=Path(raw).expanduser().resolve()
            if not path.is_file() or path.suffix.lower()!='.pdf':raise HTTPException(400,'PDF 路径不存在')
            try:
                with fitz.open(path) as pdf:
                    if pdf.needs_pass:raise ValueError('暂不支持加密 PDF，请先解除密码')
                    count=len(pdf)
                indices=list(range(count))
                spec=body.get('pages','').strip()
                if spec:
                    chosen=set()
                    for piece in spec.split(','):
                        values=[int(x) for x in piece.strip().split('-')]
                        if len(values)==1:chosen.add(values[0]-1)
                        elif len(values)==2:chosen.update(range(values[0]-1,values[1]))
                        else:raise ValueError('页码格式错误')
                    indices=sorted(chosen)
                    if not indices or min(indices)<0 or max(indices)>=count:raise ValueError('页码超出文件范围')
                bid=fingerprint(path);d=books/bid
                with LOCK:
                    if d.exists():
                        old=next((j for j in jobs.values() if j['book_id']==bid),None)
                        if old is None:raise ValueError('此书由阅读包导入，暂不能重新关联原文件')
                        if old['status'] in ('queued','running','pausing'):raise ValueError('此 PDF 正在排队或处理中')
                        old['indices']=sorted(set(old['indices'])|set(indices))
                        old.update(source=str(path),total=len(old['indices']),status='queued',error='')
                        persist();tasks.put(old['id']);created.append(old['id'])
                        continue
                    (d/'assets').mkdir(parents=True)
                    atomic_json(d/'book.json',dict(id=bid,title=path.stem,page_count=count,revision=1,status='queued',pages=[]))
                    jid=uuid.uuid4().hex
                    jobs[jid]=dict(id=jid,book_id=bid,title=path.stem,source=str(path),indices=indices,
                                   total=len(indices),done=0,status='queued',error='')
                    persist();tasks.put(jid);created.append(jid)
            except (ValueError,RuntimeError) as exc:raise HTTPException(400,str(exc))
        return {'created':created}

    @app.post('/api/jobs/{jid}/{action}')
    def job_action(jid:str,action:str):
        local_only()
        with LOCK:
            if jid not in jobs:raise HTTPException(404)
            j=jobs[jid]
            if action=='pause' and j['status']=='running':j['status']='pausing'
            elif action=='resume' and j['status'] in ('paused','failed'):
                j['status']='queued';tasks.put(jid)
            else:raise HTTPException(400,'当前状态不支持此操作')
            persist()
        return {'ok':True}

    @app.get('/api/books/{bid}/export')
    def export(bid:str):
        local_only();d=directory(bid)
        with LOCK:
            stream=io.BytesIO();export_book(d,stream)
        return Response(stream.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="cook-{bid}.zip"'})

    @app.post('/api/import')
    def receive(request:Request,file:UploadFile=File(...)):
        sync_key(request)
        with tempfile.TemporaryFile() as temp:
            size=0
            while chunk:=file.file.read(1024*1024):
                size+=len(chunk)
                if size>1024**3:raise HTTPException(413,'上传包超过 1GB')
                temp.write(chunk)
            temp.seek(0)
            try:
                with LOCK:b=import_book(temp,books)
            except (ValueError,KeyError,json.JSONDecodeError,zipfile.BadZipFile) as exc:raise HTTPException(400,str(exc))
        return {'id':b['id'],'title':b['title']}

    @app.post('/api/books/{bid}/sync')
    def sync(bid:str,body:dict):
        local_only()
        import httpx
        from urllib.parse import urlsplit
        url=body.get('url','').rstrip('/')
        parsed=urlsplit(url)
        if parsed.scheme!='https' and not(parsed.scheme=='http' and parsed.hostname in ('127.0.0.1','localhost')):
            raise HTTPException(400,'请填写 HTTPS 网站地址')
        if parsed.username or parsed.password or parsed.query or parsed.fragment:raise HTTPException(400,'网站地址格式错误')
        with tempfile.TemporaryFile() as temp:
            with LOCK:export_book(directory(bid),temp)
            temp.seek(0)
            try:
                with httpx.Client(timeout=600,follow_redirects=False) as client:
                    r=client.post(url+'/api/import',headers={'x-sync-token':body.get('token','')},
                                  files={'file':('book.zip',temp,'application/zip')})
                if r.status_code!=200:raise ValueError(f'上传失败（HTTP {r.status_code}）：'+r.text[:200])
            except (httpx.HTTPError,ValueError) as exc:raise HTTPException(400,str(exc))
        return {'ok':True}

    @app.get('/api/search')
    def search(q:str=''):
        if len(q.strip())<2:return []
        results=[]
        for p in books.glob('*/book.json'):
            b=read_json(p)
            for page in b['pages']:
                for block in page['blocks']:
                    text=block.get('text',block.get('caption',''))
                    pos=text.lower().find(q.lower())
                    if pos>=0:results.append(dict(book_id=b['id'],title=b['title'],block_id=block['id'],snippet=text[max(0,pos-25):pos+100]))
                    if len(results)>=100:return results
        return results

    @app.get('/api/books/{bid}/original/{page}')
    def original(bid:str,page:int):
        local_only();directory(bid)
        source=next((j['source'] for j in jobs.values() if j['book_id']==bid),None)
        if not source or not Path(source).is_file():raise HTTPException(404,'原 PDF 不在原来的位置')
        import fitz
        with fitz.open(source) as doc:
            if page<1 or page>len(doc):raise HTTPException(404)
            pg=doc[page-1];pix=pg.get_pixmap(matrix=fitz.Matrix(1600/pg.rect.width,1600/pg.rect.width))
            return Response(pix.tobytes('png'),media_type='image/png')

    @app.post('/api/books/{bid}/crop')
    def crop(bid:str,body:dict):
        local_only();d=directory(bid)
        page=body.get('page');box=body.get('box',[])
        if len(box)!=4 or not all(isinstance(x,(int,float)) and 0<=x<=1 for x in box) or box[2]<=box[0] or box[3]<=box[1]:
            raise HTTPException(400,'裁切范围错误')
        source=next((j['source'] for j in jobs.values() if j['book_id']==bid),None)
        if not source:raise HTTPException(404)
        import fitz
        from engine import newblock
        with fitz.open(source) as pdf:
            if not isinstance(page,int) or page<1 or page>len(pdf):raise HTTPException(400,'页码错误')
            pg=pdf[page-1];w,h=pg.rect.width,pg.rect.height
            clip=fitz.Rect(box[0]*w,box[1]*h,box[2]*w,box[3]*h)
            name='manual-'+uuid.uuid4().hex+'.png'
            pg.get_pixmap(matrix=fitz.Matrix(2,2),clip=clip).save(d/'assets'/name)
        return newblock('image',page,src=name,caption='',box=box)

    @app.get('/api/progress/{bid}')
    def progress(bid:str):
        directory(bid);p=root/'progress'/f'{bid}.json'
        return read_json(p) if p.exists() else {}

    @app.put('/api/progress/{bid}')
    def save_progress(bid:str,body:dict):
        directory(bid)
        if not isinstance(body.get('block_id',''),str) or len(body.get('block_id',''))>64:raise HTTPException(400)
        marks=body.get('bookmarks',[])
        if not isinstance(marks,list) or len(marks)>1000 or any(not isinstance(x,str) or len(x)>64 for x in marks):raise HTTPException(400)
        with LOCK:
            directory(bid)
            atomic_json(root/'progress'/f'{bid}.json',{'block_id':body.get('block_id',''),'bookmarks':marks})
        return {'ok':True}

    web=Path(__file__).parent/'web'
    app.mount('/',StaticFiles(directory=web,html=True),name='web')
    return app


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=['local','server'],default='local')
    parser.add_argument('--data',default='data')
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--host',default=None)
    parser.add_argument('--no-browser',action='store_true')
    parser.add_argument('--desktop',action='store_true')
    args=parser.parse_args()
    host=args.host or ('127.0.0.1' if args.mode=='local' else '0.0.0.0')
    if args.mode=='local' and host not in ('127.0.0.1','localhost'):parser.error('本地模式只能绑定本机')
    desktop=args.mode=='local' and (args.desktop or not args.no_browser)
    if desktop:os.environ['COOK_DESKTOP']='1'
    import uvicorn
    application=create_app(args.data,args.mode)
    server=uvicorn.Server(uvicorn.Config(application,host=host,port=args.port))
    application.state.shutdown_for_update=lambda:setattr(server,'should_exit',True)
    if desktop:
        from desktop import run_desktop,show_error
        try:run_desktop(application,server,Path(__file__).resolve().parent,args.port)
        except Exception as exc:show_error(exc);raise
    else:server.run()
