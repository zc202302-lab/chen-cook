"""HTTPS release feed, bounded downloads, code-only staging and rollback."""
import hashlib
import json
import os
import re
import shutil
import tempfile
import urllib.request
import urllib.error
import zipfile
from pathlib import Path
from urllib.parse import urljoin, urlsplit

FILES={'app.py','engine.py','storage.py','updater.py','launcher.py','desktop.py','version.json',
       'requirements.txt','requirements-local.txt','start-local.bat','Dockerfile','compose.yaml',
       '使用说明.md','第一版测试记录.md','web/index.html','web/app.js','web/style.css'}
REQUIRED={'app.py','engine.py','storage.py','updater.py','launcher.py','desktop.py','version.json',
          'requirements.txt','requirements-local.txt','web/index.html','web/app.js','web/style.css'}


def version(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d+\.\d+\.\d+',value):
        raise ValueError('版本号必须是 x.y.z 格式')
    return tuple(map(int,value.split('.')))


def current(directory):
    return json.loads((Path(directory)/'version.json').read_text(encoding='utf-8'))['version']


def https_url(url):
    p=urlsplit(url)
    if p.scheme!='https' or not p.hostname or p.username or p.password or p.fragment:
        raise ValueError('更新源必须是 HTTPS 地址，且不能包含用户名、密码或片段')
    return url


class SecureRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        https_url(newurl)
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def download(url,destination,limit):
    https_url(url)
    opener=urllib.request.build_opener(SecureRedirect())
    request=urllib.request.Request(url,headers={'User-Agent':'CookReader-Updater/1','Cache-Control':'no-cache'})
    with opener.open(request,timeout=30) as response,open(destination,'wb') as output:
        https_url(response.url)
        length=response.headers.get('Content-Length')
        if length and int(length)>limit:raise ValueError('更新文件过大')
        total=0
        while chunk:=response.read(1024*1024):
            total+=len(chunk)
            if total>limit:raise ValueError('更新文件过大')
            output.write(chunk)


def check(feed,directory,fetch=download):
    https_url(feed)
    with tempfile.TemporaryDirectory() as temp:
        p=Path(temp)/'manifest.json'
        try:fetch(feed,p,256*1024)
        except (urllib.error.URLError,TimeoutError):
            if feed!='https://cook.ziboxiaozhushou.cn/api/releases/latest':raise
            feed='https://raw.githubusercontent.com/zc202302-lab/chen-cook/main/releases/latest.json'
            fetch(feed,p,256*1024)
        info=json.loads(p.read_text(encoding='utf-8'))
    version(info.get('version'))
    if not re.fullmatch(r'[a-fA-F0-9]{64}',str(info.get('sha256',''))):raise ValueError('更新信息缺少 SHA256 校验值')
    info['url']=https_url(urljoin(feed,info.get('url','')))
    info['available']=version(info['version'])>version(current(directory))
    info['current']=current(directory)
    return info


def stage(directory,info,fetch=download):
    root=Path(directory);updates=root/'.updates';updates.mkdir(exist_ok=True)
    work=Path(tempfile.mkdtemp(prefix='download-',dir=updates))
    try:
        archive=work/'release.zip';fetch(info['url'],archive,100*1024**2)
        if hashlib.sha256(archive.read_bytes()).hexdigest().lower()!=info['sha256'].lower():
            raise ValueError('更新包校验失败，当前版本未修改')
        staged=work/'staged';staged.mkdir()
        with zipfile.ZipFile(archive) as z:
            entries=z.infolist();names=[i.filename for i in entries]
            if len(names)!=len(set(names)) or not REQUIRED.issubset(names) or any(n not in FILES for n in names):
                raise ValueError('更新包文件清单不符合要求')
            if sum(i.file_size for i in entries)>150*1024**2:raise ValueError('更新包解压后过大')
            for i in entries:
                if (i.external_attr>>16)&0o170000==0o120000:raise ValueError('不接受符号链接')
                target=staged/i.filename;target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(z.read(i.filename))
        if current(staged)!=info['version']:raise ValueError('更新包版本号与更新信息不一致')
        import ast
        for name in names:
            if name.endswith('.py'):ast.parse((staged/name).read_text(encoding='utf-8'),filename=name)
        return staged
    except Exception:
        shutil.rmtree(work,ignore_errors=True)
        raise


def install(directory,staged):
    """Code-only rollback journal survives supervisor/app restart. Data is never replaced."""
    root=Path(directory);staged=Path(staged).resolve()
    if not staged.is_relative_to((root/'.updates').resolve()):raise ValueError('更新暂存目录无效')
    names=[str(p.relative_to(staged)).replace('\\','/') for p in staged.rglob('*') if p.is_file()]
    if any(n not in FILES for n in names) or not REQUIRED.issubset(names):raise ValueError('暂存文件清单无效')
    backup=root/'.updates'/'backup'
    if backup.exists():shutil.rmtree(backup)
    backup.mkdir(parents=True)
    old=[]
    for name in names:
        dest=root/name
        if dest.is_symlink():raise ValueError('程序目录不能含符号链接')
        if dest.exists():
            (backup/name).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,backup/name);old.append(name)
    journal=dict(names=names,old=old,version=current(staged))
    (backup/'journal.json').write_text(json.dumps(journal),encoding='utf-8')
    try:
        for name in names:
            dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True)
            temp=dest.with_name(dest.name+'.update-tmp');shutil.copy2(staged/name,temp);os.replace(temp,dest)
    except Exception:
        rollback(root);raise
    return journal


def rollback(directory):
    root=Path(directory);backup=root/'.updates'/'backup'
    journal=json.loads((backup/'journal.json').read_text(encoding='utf-8'))
    for name in journal['names']:
        if name not in FILES:raise ValueError('回滚清单错误')
        if name in journal['old']:shutil.copy2(backup/name,root/name)
        else:(root/name).unlink(missing_ok=True)


def state(directory,**values):
    p=Path(directory)/'.updates';p.mkdir(exist_ok=True)
    temp=p/'status.tmp';temp.write_text(json.dumps(values,ensure_ascii=False),encoding='utf-8');os.replace(temp,p/'status.json')
