"""Stable supervisor: app exits gracefully, supervisor updates it and starts it again."""
import argparse
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

import updater


def subprocess_options():
    options={}
    if os.name=='nt':options['creationflags']=subprocess.CREATE_NO_WINDOW
    if sys.stdout is not None:options['stdout']=sys.stdout
    if sys.stderr is not None:options['stderr']=sys.stderr
    return options


def lock_instance(root):
    handle=(root/'.updates'/'launcher.lock').open('a+b')
    handle.write(b'1');handle.flush();handle.seek(0)
    try:
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except OSError:
        handle.close()
        raise RuntimeError('程序已经启动，请使用已打开的工作台')
    return handle


def healthy(port,expected,process,endpoint=None):
    deadline=time.monotonic()+40
    while time.monotonic()<deadline:
        if process.poll() is not None:return False
        try:
            if endpoint is not None:
                address=json.loads(endpoint.read_text(encoding='utf-8'))
                if address.get('pid')!=process.pid:
                    time.sleep(.4);continue
                port=address['port']
            with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/config',timeout=1) as response:
                info=json.load(response)
                if info.get('version')==expected and (not info.get('desktop') or info.get('desktop_ready')):return True
        except Exception:pass
        time.sleep(.4)
    return False


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',default='data');parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent;os.chdir(root)
    updates=root/'.updates';updates.mkdir(exist_ok=True)
    if sys.stdout is None or sys.stderr is None:
        log=(updates/'application.log').open('a',encoding='utf-8',buffering=1)
        sys.stdout=sys.stderr=log
    portable=(Path(sys.executable).parent==root/'runtime')
    try:instance_lock=lock_instance(root)
    except RuntimeError:
        if not args.no_browser:
            if os.name=='nt':
                import ctypes
                user32=ctypes.windll.user32
                user32.FindWindowW.restype=ctypes.c_void_p
                user32.ShowWindow.argtypes=[ctypes.c_void_p,ctypes.c_int]
                user32.SetForegroundWindow.argtypes=[ctypes.c_void_p]
                handle=user32.FindWindowW(None,'灶间书房 · 转换工作台')
                if handle:user32.ShowWindow(handle,9);user32.SetForegroundWindow(handle)
        return
    pending=updates/'pending.json';backup=updates/'backup'
    # An interrupted transaction is rolled back before starting the app.
    if (backup/'journal.json').exists():
        updater.rollback(root)
        (backup/'journal.json').unlink()
        pending.unlink(missing_ok=True)
        updater.state(root,phase='failed',message='上次更新中断，已恢复原版本')
    restarted=False
    while True:
        env={**os.environ,'COOK_SUPERVISED':'1','COOK_PORTABLE':'1' if portable else '0',
             'COOK_DESKTOP':'0' if args.no_browser else '1'}
        command=[sys.executable,str(root/'app.py'),'--mode','local','--data',args.data,'--port',str(args.port)]
        command.append('--no-browser' if args.no_browser else '--desktop')
        process=subprocess.Popen(command,env=env,**subprocess_options())
        if restarted and (backup/'journal.json').exists():
            expected=json.loads((backup/'journal.json').read_text())['version']
            if not healthy(args.port,expected,process,None if args.no_browser else updates/'desktop-endpoint.json'):
                process.terminate()
                try:process.wait(timeout=10)
                except subprocess.TimeoutExpired:process.kill();process.wait()
                updater.rollback(root)
                (backup/'journal.json').unlink()
                updater.state(root,phase='failed',message='新版启动失败，已恢复原版本并重启')
                continue
            (backup/'journal.json').unlink()
            updater.state(root,phase='done',message='更新完成，已自动重启',version=expected)
        try:process.wait()
        except KeyboardInterrupt:
            process.terminate();process.wait();return
        if not pending.exists():return
        request=json.loads(pending.read_text(encoding='utf-8'));pending.unlink()
        try:
            staged=Path(request['staged'])
            updater.install(root,staged)
            # Refresh dependencies only when requirement files changed.
            requirements_changed=any((backup/n).read_bytes()!=(root/n).read_bytes() for n in ['requirements.txt','requirements-local.txt'])
            if requirements_changed:
                updater.state(root,phase='installing',message='正在更新运行依赖，请保持窗口开启')
                subprocess.run([sys.executable,'-m','pip','install','-r',str(root/'requirements-local.txt')],check=True,cwd=root,**subprocess_options())
            updater.state(root,phase='restarting',message='更新已安装，正在重新启动')
        except Exception as exc:
            if (backup/'journal.json').exists():
                updater.rollback(root);(backup/'journal.json').unlink()
                # Restore old dependency specifications if installation partially changed them.
                subprocess.run([sys.executable,'-m','pip','install','-r',str(root/'requirements-local.txt')],cwd=root,**subprocess_options())
            updater.state(root,phase='failed',message='更新失败，已恢复程序文件：'+str(exc))
        restarted=True


if __name__=='__main__':
    try:main()
    except Exception as exc:
        if os.name=='nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None,str(exc),'灶间书房',0x10)
        raise
