"""Offline baseline. Every OCR block remains unreviewed until a human checks it."""
import hashlib
import re
import uuid
from pathlib import Path


def fingerprint(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()[:24]


def newblock(kind, page, **extra):
    return dict(id=uuid.uuid4().hex[:16], kind=kind, page=page,
                level=2, reviewed=False, **extra)


def reading_groups(lines, width):
    """Detect a sustained central gutter; preserve full-width bands as separators."""
    if not lines:
        return []
    lines = sorted(lines, key=lambda x: (x['box'][1], x['box'][0]))
    candidates = []
    for frac in (.42, .45, .48, .50, .52, .55, .58):
        split = width * frac
        left = [x for x in lines if x['box'][2] < split - width * .006]
        right = [x for x in lines if x['box'][0] > split + width * .006]
        if len(left) >= 5 and len(right) >= 5:
            cross = len(lines) - len(left) - len(right)
            candidates.append((min(len(left), len(right)) - cross * 2, split))
    if not candidates or max(candidates)[0] < 2:
        return [lines]
    split = max(candidates)[1]
    separators = [x for x in lines if x['box'][0] <= split <= x['box'][2]]
    groups, band = [], []
    for item in lines:
        if item in separators:
            if band:
                groups.extend([sorted([x for x in band if x['box'][0] < split], key=lambda x:x['box'][1]),
                               sorted([x for x in band if x['box'][0] >= split], key=lambda x:x['box'][1])])
                band = []
            groups.append([item])
        else:
            band.append(item)
    if band:
        groups.extend([sorted([x for x in band if x['box'][0] < split], key=lambda x:x['box'][1]),
                       sorted([x for x in band if x['box'][0] >= split], key=lambda x:x['box'][1])])
    return [g for g in groups if g]


class Converter:
    def __init__(self):
        from rapidocr_onnxruntime import RapidOCR
        self.ocr = RapidOCR(intra_op_num_threads=4, inter_op_num_threads=1)

    def page(self, pdf, index, assets):
        import numpy as np
        import cv2
        from PIL import Image
        page = pdf[index]
        scale = min(2.5, 1800 / max(page.rect.width, page.rect.height))
        import fitz
        pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
        rgb = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, 3).copy()
        h, w = rgb.shape[:2]
        result, _ = self.ocr(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
        lines = []
        for points, text, score in result or []:
            a = np.array(points)
            box = [float(a[:,0].min()), float(a[:,1].min()), float(a[:,0].max()), float(a[:,1].max())]
            lines.append(dict(text=text, confidence=float(score), box=box))
        blocks = []
        heights = sorted(x['box'][3]-x['box'][1] for x in lines)
        typical = heights[len(heights)//2] if heights else 15
        for group in reading_groups(lines, w):
            current = []
            def flush():
                if current:
                    box = [min(x['box'][0] for x in current), min(x['box'][1] for x in current),
                           max(x['box'][2] for x in current), max(x['box'][3] for x in current)]
                    blocks.append(newblock('text', index+1, text='\n'.join(x['text'] for x in current),
                                           box=[round(v/(w if i%2==0 else h),5) for i,v in enumerate(box)],
                                           confidence=round(min(x['confidence'] for x in current),4)))
                    current.clear()
            for line in group:
                text, box = line['text'], line['box']
                headline = (len(text) <= 35 and box[3]-box[1] > typical * 1.30
                            and len(re.findall(r'[\u4e00-\u9fff]',text))>=2
                            and box[0]<w*.88)
                label = bool(re.match(r'^(配方\s*\d+|步骤\s*\d+|制作关键|使用贴士|原料[：:]|调料[：:]|制作[：:])',text))
                if headline:
                    flush()
                    blocks.append(newblock('heading',index+1,text=text,confidence=line['confidence'],
                                           box=[round(v/(w if i%2==0 else h),5) for i,v in enumerate(box)]))
                else:
                    if label or (current and box[1]-current[-1]['box'][3] > typical*.8):
                        flush()
                    current.append(line)
            flush()
        # Remove OCR text before detecting large non-white regions. Suggestions require review.
        mask = cv2.inRange(rgb, np.array([0,0,0],np.uint8), np.array([238,238,238],np.uint8))
        for line in lines:
            x1,y1,x2,y2 = map(int,line['box'])
            cv2.rectangle(mask,(max(0,x1-3),max(0,y1-3)),(min(w,x2+3),min(h,y2+3)),0,-1)
        mask = cv2.morphologyEx(mask,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
        mask = cv2.morphologyEx(mask,cv2.MORPH_CLOSE,np.ones((11,11),np.uint8))
        contours,_ = cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        rectangles=[]
        for c in sorted(contours,key=lambda c:cv2.boundingRect(c)[1]):
            x,y,cw,ch=cv2.boundingRect(c)
            if cw*ch < w*h*.018 or cw < w*.13 or ch < h*.045:
                continue
            # Avoid exporting a page-sized background as an alleged extracted photograph.
            if cw*ch > w*h*.85:
                continue
            rectangles.append([x,y,x+cw,y+ch])
        # Bounding rectangles of disjoint contours can overlap: merge before cropping.
        changed=True
        while changed:
            changed=False
            for i,a in enumerate(rectangles):
                for j in range(i+1,len(rectangles)):
                    b=rectangles[j]
                    if min(a[2],b[2])+6>max(a[0],b[0]) and min(a[3],b[3])+6>max(a[1],b[1]):
                        rectangles[i]=[min(a[0],b[0]),min(a[1],b[1]),max(a[2],b[2]),max(a[3],b[3])]
                        rectangles.pop(j);changed=True;break
                if changed:break
        image_blocks=[]
        for x,y,x2,y2 in sorted(rectangles,key=lambda b:b[1]):
            cw,ch=x2-x,y2-y
            name=f'p{index+1}-{uuid.uuid4().hex[:12]}.png'
            Image.fromarray(rgb[y:y+ch,x:x+cw]).save(assets/name)
            image_blocks.append(newblock('image',index+1,src=name,caption='',
                                         box=[x/w,y/h,(x+cw)/w,(y+ch)/h],
                                         note='自动候选裁图，请检查裁切边界和所属内容'))
        for block in image_blocks:
            # First version uses spatial attachment only; all candidates remain unreviewed.
            before = [i for i,b in enumerate(blocks) if b.get('box',[0,0,0,0])[1] <= block['box'][1]]
            blocks.insert((before[-1]+1) if before else 0,block)
        if not blocks:
            blocks=[newblock('text',index+1,text='',note='本页未识别出内容，必须对照原页检查')]
        return dict(page=index+1,blocks=blocks,ocr_lines=lines,ocr_size=[w,h],
                    warning='自动初稿：文字、标题、阅读顺序和图片归属均尚未核对')


# Stage two: structure is an overlay. OCR text, blocks, images and their IDs stay intact.
_LEADER = r'[·.．…。•⋯\s]'
_PAGE_TOKEN = re.compile(r'^'+_LEADER+r'*(\d{1,4})'+_LEADER+r'*$')
_INLINE_ENTRY = re.compile(r'^(.*?)('+_LEADER+r'+)(\d{1,4})\s*$')

def _title_key(text):
    return re.sub(r'[\s·.．…。•⋯:：、，,（）()]','',text).casefold()


def catalog_rows(text):
    """Conservative fallback: do not attach an orphan page number to the next title."""
    rows=[];pending=[]
    def raw_pending():
        if pending:
            rows.append({'raw':'\n'.join(pending)})
            pending.clear()
    for line in text.splitlines():
        if not line.strip():
            raw_pending();continue
        token=_PAGE_TOKEN.fullmatch(line.strip())
        inline=_INLINE_ENTRY.fullmatch(line.strip())
        if token:
            if pending:
                title=re.sub(_LEADER+r'+$','',''.join(pending)).strip()
                if title:
                    rows.append({'title':title,'printed_page':token[1],
                                 'raw':'\n'.join(pending+[line]),'evidence':'text-order'})
                    pending.clear();continue
            raw_pending();rows.append({'raw':line})
        elif inline and inline[1].strip():
            raw_pending()
            rows.append({'title':inline[1].strip(),'printed_page':inline[3],
                         'raw':line,'evidence':'same-line'})
        else:
            # Two title-looking lines may be a wrapped title or scrambled rows.
            # Never guess which title belongs to a subsequent page number.
            if pending and sum(t.count('（')+t.count('(')-t.count('）')-t.count(')') for t in pending)>0:
                pending.append(line);continue
            if pending:raw_pending()
            pending.append(line)
    raw_pending()
    return rows


def _spatial_catalog_rows(block,page):
    """Recover OCR rows in this block using their original 2-D positions."""
    from collections import Counter
    size=page.get('ocr_size')
    if not size or not page.get('ocr_lines') or not block.get('box'):return None
    w,h=size;bx=block['box'];wanted=Counter(block['text'].splitlines());selected=[]
    for line in page['ocr_lines']:
        if not isinstance(line,dict) or not wanted[line.get('text')]:continue
        x1,y1,x2,y2=line['box'];cx=(x1+x2)/2/w;cy=(y1+y2)/2/h
        if bx[0]-.002<=cx<=bx[2]+.002 and bx[1]-.002<=cy<=bx[3]+.002:
            wanted[line['text']]-=1;selected.append(line)
    if any(wanted.values()):return None  # Edited text: the OCR cache is no longer authoritative.
    if not selected:return None
    heights=sorted(x['box'][3]-x['box'][1] for x in selected)
    tolerance=heights[len(heights)//2]*.55
    bands=[]
    for line in sorted(selected,key=lambda x:(sum(x['box'][1::2])/2,x['box'][0])):
        center=(line['box'][1]+line['box'][3])/2
        if not bands or abs(center-bands[-1][0])>tolerance:bands.append([center,[line]])
        else:bands[-1][1].append(line)
    rows=[]
    for _,band in bands:
        row=' '.join(x['text'] for x in sorted(band,key=lambda x:x['box'][0]))
        parsed=catalog_rows(row)
        for entry in parsed:
            if 'title' in entry:entry['evidence']='ocr-row'
        rows.extend(parsed)
    return rows


def organize_book(book):
    """Build catalog/hierarchy from evidence, with no rewriting or content deletion."""
    catalog_pages=set();count=0
    # Marginal labels need geometric evidence; never discard text based on a stop-word list.
    occurrences={}
    for p in book['pages']:
        for b in p['blocks']:
            text=b.get('text','').strip()
            for line in text.splitlines():
                if line.strip():occurrences.setdefault(line.strip(),set()).add(p['page'])
    for p in book['pages']:
        for b in p['blocks']:
            box=b.get('box');text=b.get('text','').strip()
            if not box or not text or len(text)>18 or b.get('reviewed'):continue
            vertical=(box[0]<.07 or box[2]>.97) and box[2]-box[0]<.07 and box[3]-box[1]>1.3*(box[2]-box[0])
            repeated_edge=len(occurrences[text])>=2 and (box[3]<.10 or box[1]>.93)
            if (vertical and len(occurrences.get(text,set()))>=2) or repeated_edge:b['role']='page_furniture'

    for page in book['pages']:
        texts=[b.get('text','') for b in page['blocks'] if b['kind']!='image']
        explicit=any(re.search(r'目录|CONTENTS',t,re.I) and len(t)<40 for t in texts)
        candidates=sum(sum('title' in r for r in catalog_rows(t)) for t in texts)
        if not (explicit and candidates>=2 or candidates>=6):continue
        catalog_pages.add(page['page'])
        for b in page['blocks']:
            if b['kind']=='image' or b.get('role')=='page_furniture':continue
            rows=_spatial_catalog_rows(b,page) or catalog_rows(b.get('text',''))
            entries=sum('title' in r for r in rows)
            # Spatial matching repairs title/number ordering; unresolved rows stay visible.
            if entries:
                b['catalog']={'text_snapshot':b['text'],'rows':rows}
                b['role']='catalog';count+=entries
            elif b['kind']=='heading' and not b.get('reviewed'):
                b['role']='chapter';b['level']=1
    blocks=[b for p in book['pages'] for b in p['blocks']]
    targets={}
    for p in book['pages']:
        if p['page'] in catalog_pages:continue
        for b in p['blocks']:
            if b['kind']=='image' or b.get('role')=='page_furniture':continue
            # Full standalone titles only; no fuzzy matching or guessed PDF page offsets.
            first=b.get('text','').strip().split('\n')[0]
            if len(first)<=60:targets.setdefault(_title_key(first),[]).append(b)
            if not b.get('reviewed'):
                text=b.get('text','').strip()
                if re.match(r'^配方\s*\d+$',text):b['role']='subheading';b['level']=3
                elif re.match(r'^(步骤\s*\d+|制作方法|制作步骤)',text):b['role']='procedure'
                elif re.match(r'^(原料|主料|辅料|调料)[：:]',text):b['role']='ingredients'
                elif re.match(r'^(制作关键|使用贴士)',text):b['role']='tips'
    linked=0
    for b in blocks:
        catalog=b.get('catalog')
        if not catalog or catalog.get('text_snapshot')!=b.get('text'):continue
        for row in catalog['rows']:
            row.pop('target_id',None)
            if 'title' not in row:continue
            matches=targets.get(_title_key(row['title']),[])
            if len(matches)==1:
                target=matches[0];row['target_id']=target['id'];linked+=1
                if not target.get('reviewed'):
                    target['role']='recipe';target['level']=2
    book['structure_version']=1
    return {'entries':count,'linked':linked,'unresolved':count-linked}
